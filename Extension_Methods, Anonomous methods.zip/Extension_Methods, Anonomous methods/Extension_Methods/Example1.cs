﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extension_Methods
{
   
    public static class Example1
    {
        //This extension method adds a Reverse method to the string class, which reverses the order of the characters in the string
        public static string Reverse(this string s) //  The this keyword before the first parameter indicates that this is an extension method
                                                    //  for the string class.
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }


        public static void CallFromMain()
        {
            string myString = "hello world";
            string reversedString = myString.Reverse();
            Console.WriteLine(reversedString); // Output: "dlrow olleh"
        }


    }
}
