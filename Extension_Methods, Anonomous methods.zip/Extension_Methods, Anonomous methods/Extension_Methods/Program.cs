﻿using System;

namespace Extension_Methods
{
    public static class Program
    {
       

        static void Main(string[] args)
        {
            /*
             Extension methods are a feature in C# and other .NET languages that allow you to add new methods to existing classes, without
             modifying the original class or creating a subclass. Extension methods are defined as static methods in a static class, and are 
            called as if they were instance methods of the extended class.
             */

            Example1.CallFromMain();
            Example2.CallFromMain();

            Anonomous_Methods a = new Anonomous_Methods();
            a.CallFromMain();
        }
    }
}
