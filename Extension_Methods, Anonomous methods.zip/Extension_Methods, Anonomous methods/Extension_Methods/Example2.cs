﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extension_Methods
{
    public static class Example2
    {
        //------|third party source code|------

        public  class A
        {
            public int add(int a , int b)
            {
                return a + b;
            }
        }
        //-------------------------------------


        //---|function that needed to be added to A|------------

        public static int subtract_need_to_be_added_to_A(this A obj, int a , int b)
        {
            return a - b;
        }
        //-----------------------------------------------------


        public static void CallFromMain()
        {
            A a = new A();  

            Console.WriteLine(a.subtract_need_to_be_added_to_A(20,10));
        }

    }
}
