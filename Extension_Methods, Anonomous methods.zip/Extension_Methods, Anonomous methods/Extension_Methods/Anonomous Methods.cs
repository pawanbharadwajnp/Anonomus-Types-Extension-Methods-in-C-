﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extension_Methods
{

    public class Anonomous_Methods
    {

        Action greet = delegate // anonomous function
        {
            Console.WriteLine("Hello" );
        };

        public  void CallFromMain()
        {
            greet(); // Output: Hello, John

        }

    }
}
